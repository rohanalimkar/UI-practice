<?php
	 if (!isset($_SESSION['TYPE'])=='Administrator'){
      redirect(web_root."index.php");
     }

?>
<div class="container">
 <div class="row">
 	<h1>Under Developement</h1>
 </div>
</div>